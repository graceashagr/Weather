package com.example.weather.repository.retrofit.model;

import com.google.gson.annotations.SerializedName;

/***
 * Class to receive the weather data
 */
public class Weather {

    @SerializedName("description")
    private String description;

    @SerializedName("icon")
    private String icon;

    private Main main;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public Main getMain() {
        return main;
    }

    public void setMain(Main main) {
        this.main = main;
    }
}
