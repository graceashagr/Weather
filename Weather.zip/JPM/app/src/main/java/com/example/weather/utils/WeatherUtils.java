package com.example.weather.utils;


import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import com.example.weather.MainActivity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

public class WeatherUtils implements WeatherUtilsInterface {

    private Context context;
    private FusedLocationProviderClient fusedLocationClient;

    public WeatherUtils(MainActivity context) {
        this.context = context;
    }

    @Override
    public LocationManager getLocationManager() {
        return (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
    }

    @Override
    public Location getCurrentLocation() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(context);

        if (isLocationPermissionGranted()) {

            fusedLocationClient.getLastLocation()
                    .addOnSuccessListener((MainActivity) context, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            // Got last known location. In some rare situations this can be null.
                            if (location != null) {
                                // Logic to handle location object
                            }
                        }
                    });
       }
        return null;
    }



    private Boolean isLocationPermissionGranted(){
        boolean permissionGranted;
        if (ActivityCompat.checkSelfPermission(
                context,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
        ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                context,
                android.Manifest.permission.ACCESS_FINE_LOCATION
        ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                    (MainActivity)context,
                    new String[]{
                            android.Manifest.permission.ACCESS_FINE_LOCATION,
                            android.Manifest.permission.ACCESS_COARSE_LOCATION
                    },
                    Constants.USER_PERMISSION_CODE
            );
            permissionGranted =  false;
        } else {
            permissionGranted = true;
        }

        return permissionGranted;
    }
}
