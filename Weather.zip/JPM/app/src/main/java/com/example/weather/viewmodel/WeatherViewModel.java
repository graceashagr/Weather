package com.example.weather.viewmodel;

import androidx.lifecycle.ViewModel;

public class WeatherViewModel extends ViewModel {

}
