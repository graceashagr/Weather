package com.example.weather.repository.retrofit.model;

import com.google.gson.annotations.SerializedName;

public class Main {

    @SerializedName("temp")
    private String temperature;

    @SerializedName("feels_like")
    private String feelsLike;

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getFeelsLike() {
        return feelsLike;
    }

    public void setFeelsLike(String feelsLike) {
        this.feelsLike = feelsLike;
    }
}
