package com.example.weather.utils;

public class Constants {
    public static int USER_PERMISSION_CODE = 1;

    public static String BASE_URL = "";
}
