package com.example.weather.repository.retrofit.api;

import com.example.weather.repository.retrofit.model.Weather;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface WeatherAPI {

    // Method to get the Current Weather for the OpenWeatherMAp.org
    @GET()
    Call<Weather> getCurrentWeather(@Query("q") String cityName);
}
