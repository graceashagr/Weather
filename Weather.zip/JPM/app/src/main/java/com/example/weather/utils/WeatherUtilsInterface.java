package com.example.weather.utils;

import android.location.Location;
import android.location.LocationManager;

public interface WeatherUtilsInterface {
    public abstract LocationManager getLocationManager();

    public abstract Location getCurrentLocation();
}
